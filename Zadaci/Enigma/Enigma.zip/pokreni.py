from enigma import Enigma

zagonetka = Enigma()