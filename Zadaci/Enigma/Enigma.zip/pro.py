
print(-12%26)

for b in range(2,-1,-1):
    print(b,end=',')

for b in range(3):
    print(b,end=',')

niz=''
for b in range(65536):
    if b<55296 or b>57344:
        niz += chr(b)

print(niz)
