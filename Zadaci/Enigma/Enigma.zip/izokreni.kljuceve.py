abeceda = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
kolutovi = ('EKMFLGDQVZNTOWYHXUSPAIBRCJ',
            'AJDKSIRUXBLHWTMCQGZNPYFVOE',
            'BDFHJLCPRTXVZNYEIWGAKMUSQO',
            'ESOVPZJAYQUIRHXLNFTGKDCMWB',
            'VZBRGITYUPSDNHLXAWMJQOFECK')

for kolut in kolutovi:
    for slovo in abeceda:
        kazalo = kolut.find(slovo)
        print(abeceda[kazalo], end='')
    print(' ')




