abeceda = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
slovo_prijenosa = ('Q','E','V','J','Z')

for slovo in slovo_prijenosa:
    print(abeceda.find(slovo)+1)